import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;
import java.net.InetAddress;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.PrintWriter;

public class Server
{
	private int PORT = 25535;
	private Scanner reader;
	private PrintWriter writer;
	private String text;
	private boolean quit;
	private ServerSocket serverSocket;
	
	private JFrame frame;
	private JPanel panel;
	private GridBagConstraints constraints;
	private JLabel label;
	private JTextField textfield;
	private JButton button;
	
	public static void main(String[] args)
	{
		new Server();
	}
	
	public Server()
	{
		try
		{
			serverSocket = new ServerSocket(PORT, 1, InetAddress.getLocalHost());
			text = "<html>Running server on:"
						+ "<br/>Host = " + serverSocket.getInetAddress().getHostAddress()
						+ "<br/>Port = " + serverSocket.getLocalPort() + "</html>";
			setupGUI();
			
			while(true)
			{
				Socket clientSocket = serverSocket.accept();
				addText("Client connected from " + clientSocket.getLocalAddress().getHostName());
				
				reader = new Scanner(clientSocket.getInputStream());
				writer = new PrintWriter(clientSocket.getOutputStream());
				
				quit = false;
				
				button.addActionListener(new ActionListener()
		        {
		        	public void actionPerformed(ActionEvent e)
		        	{
		        		try
						{
		        			writer.println(textfield.getText());
							writer.flush();
							addText("Server: " + textfield.getText());
							textfield.setText("");
						}
						catch(Exception io_error)
						{
							JOptionPane.showMessageDialog(frame, "Connection lost.");
							reader.close();
							writer.close();
							quit = true;
						}
		        	}
		        });
				
				Thread read = new Thread() {
					public void run()
					{
						while(!quit)
						{
							try
							{
								addText("Client: " + reader.nextLine());
							}
							catch(Exception io_error)
							{
								JOptionPane.showMessageDialog(frame, "Connection lost.");
								reader.close();
								writer.close();
								quit = true;
							}
						}
					}
				};
				read.start();
			}
		}
		catch (Exception exception)
		{
			System.out.println("An error occured.");
			exception.printStackTrace();
		}
	}
	
	private void setupGUI()
	{
        frame = new JFrame("Messenger");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(450, 400);
        
        panel = new JPanel(new GridBagLayout());
        constraints = new GridBagConstraints();
        
        label = new JLabel(text, SwingConstants.LEFT);
        label.setVerticalAlignment(SwingConstants.BOTTOM);
        constraints.gridx = 0;
        constraints.gridy = 0;
        constraints.fill = GridBagConstraints.BOTH;
        constraints.weighty = 0.9;
        constraints.gridwidth = 2;
        label.setOpaque(true);
        label.setBackground(Color.WHITE);
        panel.add(label, constraints);
        
        textfield = new JTextField();
        constraints.gridx = 0;
        constraints.gridy = 1;
        constraints.fill = GridBagConstraints.HORIZONTAL;
        constraints.weightx = 0.8;
        constraints.weighty = 0.1;
        constraints.gridwidth = 1;
        panel.add(textfield, constraints);
        
        button = new JButton("Send");
        constraints.gridx = 1;
        constraints.gridy = 1;
        constraints.fill = GridBagConstraints.HORIZONTAL;
        constraints.weightx = 0.2;
        constraints.weighty = 0.1;
        constraints.gridwidth = 1;
        panel.add(button, constraints);
        
        frame.setContentPane(panel);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        
        Thread thread = new Thread() {
        	public void run()
			{
        		try
        		{
        			while(true)
    				{
    					label.setText(text);
    					Thread.sleep(500);
    				}
        		}
        		catch(Exception e)
        		{
        			e.printStackTrace();
        		}
			}
        };
        thread.start();
	}
	
	private void addText(String textToAdd)
	{
		text = text.substring(0, text.length()-7);
		text += "<br/>" + textToAdd + "</html>";
	}
}