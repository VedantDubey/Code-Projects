import java.net.Socket;
import java.util.Scanner;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.PrintWriter;

public class Client
{
	private String HOST;
	private int PORT;
	private Scanner reader;
	private PrintWriter writer;
	private String text;
	private Socket socket;
	
	private JFrame frame;
	private JPanel panel;
	private GridBagConstraints constraints;
	private JLabel label;
	private JTextField textfield;
	private JButton button;
   
	public static void main(String[] args)
	{
		new Client();
	}
	
	public Client()
	{
		String hostInput = JOptionPane.showInputDialog("Enter Server IP Address:", "192.168.86.173");
		String portInput = JOptionPane.showInputDialog("Enter Server Port Number:", "25535");
		
		if(hostInput == null || portInput == null)
		{
			System.exit(0);
		}
		else
		{
			HOST = hostInput;
			PORT = Integer.parseInt(portInput);
		}
		
		try
		{
			socket = new Socket(HOST, PORT);
			text = "<html>Connected to server.</html>";
			
			setupGUI();
			
			reader = new Scanner(socket.getInputStream());
			writer = new PrintWriter(socket.getOutputStream());
			
			button.addActionListener(new ActionListener()
	        {
	        	public void actionPerformed(ActionEvent e)
	        	{
	        		try
	        		{
	        			writer.println(textfield.getText());
		        		writer.flush();
						addText("Client: " + textfield.getText());
						textfield.setText("");
	        		}
	        		catch(Exception io_error)
	        		{
	        			JOptionPane.showMessageDialog(frame, "Connection lost.");
	        			reader.close();
	        			writer.close();
						System.exit(0);
	        		}
	        	}
	        });
			
			Thread read = new Thread() {
				public void run()
				{
					while(true)
					{
						try
						{
							addText("Server: " + reader.nextLine());
						}
						catch(Exception io_error)
						{
							JOptionPane.showMessageDialog(frame, "Connection lost.");
		        			reader.close();
		        			writer.close();
							System.exit(0);
						}
					}
				}
			};
			read.start();
		}
		catch (Exception exception)
		{
			JOptionPane.showMessageDialog(frame, "Unable to connect.");
			System.exit(0);
		}
	}
	
	private void setupGUI()
	{
        frame = new JFrame("Messenger");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(450, 400);
        
        panel = new JPanel(new GridBagLayout());
        constraints = new GridBagConstraints();
        
        label = new JLabel(text, SwingConstants.LEFT);
        label.setVerticalAlignment(SwingConstants.BOTTOM);
        constraints.gridx = 0;
        constraints.gridy = 0;
        constraints.fill = GridBagConstraints.BOTH;
        constraints.weighty = 0.9;
        constraints.gridwidth = 2;
        label.setOpaque(true);
        label.setBackground(Color.WHITE);
        panel.add(label, constraints);
        
        textfield = new JTextField();
        constraints.gridx = 0;
        constraints.gridy = 1;
        constraints.fill = GridBagConstraints.HORIZONTAL;
        constraints.weightx = 0.8;
        constraints.weighty = 0.1;
        constraints.gridwidth = 1;
        panel.add(textfield, constraints);
        
        button = new JButton("Send");
        constraints.gridx = 1;
        constraints.gridy = 1;
        constraints.fill = GridBagConstraints.HORIZONTAL;
        constraints.weightx = 0.2;
        constraints.weighty = 0.1;
        constraints.gridwidth = 1;
        panel.add(button, constraints);
        
        frame.setContentPane(panel);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        
        Thread thread = new Thread() {
        	public void run()
			{
        		try
        		{
        			while(true)
    				{
    					label.setText(text);
    					Thread.sleep(500);
    				}
        		}
        		catch(Exception e)
        		{
        			e.printStackTrace();
        		}
			}
        };
        thread.start();
	}
	
	private void addText(String textToAdd)
	{
		text = text.substring(0, text.length()-7);
		text += "<br/>" + textToAdd + "</html>";
	}
}